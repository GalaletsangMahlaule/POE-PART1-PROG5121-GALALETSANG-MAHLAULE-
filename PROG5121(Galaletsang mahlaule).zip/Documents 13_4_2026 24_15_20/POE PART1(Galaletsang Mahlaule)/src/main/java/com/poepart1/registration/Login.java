/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poepart1.registration;



/**
 *
 * @author Galaletsang
 */
import javax.swing.JOptionPane;

public class Login {
    
    // Declaring variables to store registered details
    private String storedUsername;
    private String storedPassword;
    private String storedCellNumber;
    private String storedFirstName;
    private String storedLastName;

    // Constructor (linking from Registration stays the same)
    public Login(String username, String password, String cellNumber, String firstName, String lastName) {
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedCellNumber = cellNumber;
        this.storedFirstName = firstName;
        this.storedLastName = lastName;
    }

    // method to check username format
    public boolean checkUserName(String userName){
        return userName.contains("_") && userName.length() <= 5;
    }

    // method to check password complexity
    public boolean checkPasswordComplexity(String password){
        
        boolean hasNumber = false;
        boolean hasCap = false;
        boolean hasChar = false;
        char current;
        
        // looping through password
        for (int i = 0; i < password.length(); i++){
            current = password.charAt(i);

            if(Character.isDigit(current)){
                hasNumber = true;
            }
            else if(Character.isUpperCase(current)){
                hasCap = true;
            }
            else if (!(Character.isLetterOrDigit(current))){
                hasChar = true;
            }
        }
        
        // checking all conditions
        return password.length() >= 8 && hasNumber && hasCap && hasChar;
    }

    // method to check cellphone format
    public boolean checkCellPhoneNumber(String cell){
        return cell.startsWith("+27") && cell.length() == 12;
    }

    // main login process
    public void startLogin(){
        
        boolean loggedIn = false;

        // loop until user enters correct details
        while(!loggedIn){

            JOptionPane.showMessageDialog(null, "-- PLEASE LOGIN --");

            // asking for name (used for final message)
            String firstName = JOptionPane.showInputDialog("Enter your first name:");
            String lastName = JOptionPane.showInputDialog("Enter your last name:");

            //  USERNAME LOOP 
            String username;
            do{
                username = JOptionPane.showInputDialog("Enter username:");

                if(!checkUserName(username)){
                    JOptionPane.showMessageDialog(null, "Username must contain '_' and be max 5 characters.");
                }

            }while(!checkUserName(username));

            // PASSWORD LOOP
            String password;
            do{
                password = JOptionPane.showInputDialog("Enter password:");

                if(!checkPasswordComplexity(password)){
                    JOptionPane.showMessageDialog(null, "Password must be at least 8 characters and include capital letter, number and special character.");
                }

            }while(!checkPasswordComplexity(password));

            // CELL NUMBER LOOP 
            String cell;
            do{
                cell = JOptionPane.showInputDialog("Enter cellphone number:");

                if(!checkCellPhoneNumber(cell)){
                    JOptionPane.showMessageDialog(null, "Cell number must start with +27 and be 12 digits.");
                }

            }while(!checkCellPhoneNumber(cell));

            // FINAL CHECK (compare with registered details)
            if(username.equals(storedUsername) &&
               password.equals(storedPassword) &&
               cell.equals(storedCellNumber) &&
               firstName.equals(storedFirstName) &&
               lastName.equals(storedLastName)){

                // success message
                JOptionPane.showMessageDialog(null,
                        "Welcome " + storedFirstName + " " + storedLastName + ", it is great to see you again.");

                loggedIn = true;

            }else{
                // if anything is wrong
                JOptionPane.showMessageDialog(null,
                        "Incorrect details, please try again.");
            }
        }
    }
}

